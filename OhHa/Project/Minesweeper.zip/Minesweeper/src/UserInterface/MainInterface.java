package UserInterface;

import java.io.FileNotFoundException;

/**
 *
 * @author Madeleine Ekblom
 * @since 2012-11-06
 */
public class MainInterface {

    public static void main(String[] args) throws FileNotFoundException {
        GameBoard minesweeper = new GameBoard(9,9,10);
    }
}
